			</div> <!-- end content -->
			<!-- footer -->
			<div id="footer">
				El pié de página.
			</div><!-- end footer -->
		</div> <!-- end container -->
	</div> <!-- end subwrapper -->
	
</div> <!-- end wrapper -->

<?php wp_footer(); ?>
</body>
</html>